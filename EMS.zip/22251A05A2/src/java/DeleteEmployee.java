
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DeleteEmployee extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        out.println("<html>");;
        out.println("<head>");
        out.println("<title>Delete Employee</title>");
         out.println("<style>");
        out.println("body {");
        out.println("    font-family: Arial, sans-serif;");
        out.println("    background-color: #E8F0FE;");
        out.println("    margin: 0;");
        out.println("    padding: 0;");
        out.println("    display: flex;");
        out.println("    flex-direction: column;");
        out.println("    justify-content: center;");
        out.println("    align-items: center;");
        out.println("    height: 100vh;");
        out.println("    text-align: center;");
        out.println("}");
        out.println("h2 {");
        out.println("    color: #333;");
        out.println("    margin-bottom: 20px;");
        out.println("}");
        out.println("form {");
        out.println("    background: #ffffff;");
        out.println("    border: 1px solid #dddddd;");
        out.println("    text-align: left;");
        out.println("    border-radius: 8px;");
        out.println("    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);");
        out.println("    padding: 20px;");
        out.println("    max-width: 400px;");
        out.println("    width: 100%;");
        out.println("}");
        out.println("form input[type='number'] {");
        out.println("    width: calc(100% - 20px);");
        out.println("    padding: 10px;");
        out.println("    margin: 10px 0;");
        out.println("    border: 1px solid #cccccc;");
        out.println("    border-radius: 4px;");
        out.println("    font-size: 14px;");
        out.println("    box-sizing: border-box;");
        out.println("}");
        out.println("form input[type='submit'] {");
        out.println("    width: 100%;");
        out.println("    background-color: #4A90E2;");
        out.println("    color: white;");
        out.println("    border: none;");
        out.println("    border-radius: 4px;");
        out.println("    padding: 10px;");
        out.println("    font-size: 16px;");
        out.println("    cursor: pointer;");
        out.println("}");
        out.println("form input[type='submit']:hover {");
        out.println("    background-color: #3B7BCA;");
        out.println("}");
        out.println(".message {");
        out.println("    background-color: #4CAF50;");
        out.println("    color: white;");
        out.println("    padding: 10px 20px;");
        out.println("    margin: 20px 0;");
        out.println("    margin-top: 30px;");
        
        out.println("    border-radius: 4px;");
        out.println("    font-size: 18px;");
        out.println("}");
        out.println(".view-link {");
        out.println("    background-color: #4A90E2;");
        out.println("    color: white;");
        out.println("    padding: 10px 20px;");
        out.println("    text-decoration: none;");
        out.println("    border-radius: 4px;");
        out.println("    font-size: 16px;");
        out.println("}");
        out.println(".view-link:hover {");
        out.println("    background-color: #3B7BCA;");
        out.println("}");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Delete Employee</h2>");
        out.println("<form  >");
        out.println("ID: <input type='number' name='empId' required><br>");
        out.println("<input type='submit' value='Delete Employee'>");
        out.println("</form>");
        out.println("</body></html>");
        
        //int empId = Integer.parseInt(request.getParameter("empId"));

//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//           Connection con = DriverManager.getConnection ("jdbc:mysql://localhost:3306/fsd" ,"root", "password" );
//            Statement stmt = con.createStatement();
//            String query = "DELETE FROM emp WHERE Id = " + empId;
//            stmt.executeUpdate(query);
//            response.sendRedirect("ViewEmployee"); // Redirect to view employees page
//        } catch (SQLException e) {
//            e.printStackTrace();
//        } catch (ClassNotFoundException ex) {
//            Logger.getLogger(DeleteEmployee.class.getName()).log(Level.SEVERE, null, ex);
//        }
            String empIdParam = request.getParameter("empId");
        if (empIdParam != null && !empIdParam.isEmpty()) {
            int empId = Integer.parseInt(empIdParam);
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fsd", "root", "password");
                Statement stmt = con.createStatement();
                String query = "DELETE FROM emp WHERE Id = " + empId;
                int rowsAffected = stmt.executeUpdate(query);
                
                // Show success message
                if (rowsAffected > 0) {
                    out.println("<div class='message'>Employee with ID " + empId + " has been deleted successfully.</div>");
                } else {
                    out.println("<div class='message'>No employee found with ID " + empId + ".</div>");
                }
                
                // Link to view the employees
                out.println("<a href='ViewEmployee' class='view-link'>View Employees</a>");
                //out.println("<a href='Main' class='view-link'>Main Menu</a>");
                
            } catch (SQLException e) {
                e.printStackTrace();
                out.println("<div class='message'>SQL Error: " + e.getMessage() + "</div>");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(DeleteEmployee.class.getName()).log(Level.SEVERE, null, ex);
            }
        } 
    }
}
