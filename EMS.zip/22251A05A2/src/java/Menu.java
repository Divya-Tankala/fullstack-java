import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Menu extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<head>");
        out.println("<style>");
        out.println("body {");
        out.println("    font-family: Arial, sans-serif;");
        out.println("    background-color: #E8F0FE ;");
        out.println("    margin: 0;");
        out.println("    padding: 0;");
        out.println("    text-align: center;");
        out.println("    display: flex;");
        out.println("    justify-content: center;");
        out.println("    align-items: center;");
        out.println("    flex-direction: column;");
        out.println("    height: 100vh;");
        out.println("}");
        out.println("h2 {");
        out.println("    color: #333;");
        out.println("    margin-top: 50px;");
        out.println("}");
        out.println("ul {");
        out.println("    list-style-type: none;");
        out.println("    padding: 0;");
        out.println("    margin: 20px 0;");
        out.println("    display: flex;");
        out.println("    justify-content: space-around;");
        out.println("    flex-wrap: wrap;");
        out.println("}");
        out.println("li {");
        out.println("    margin: 10px;");
        out.println("}");
        out.println("a {");
        out.println("    background-color: #4A90E2;");
        out.println("    color: white;");
        out.println("    padding: 12px 20px;");
        out.println("    text-decoration: none;");
        out.println("    border-radius: 5px;");
        out.println("    font-size: 18px;");
        out.println("    display: inline-block;");
        out.println("    transition: background-color 0.3s;");
        out.println("}");
        out.println("a:hover {");
        out.println("    background-color: #3B7BCA;");
        out.println("}");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Menu</h1>");
        out.println("<ul>");
        out.println("<li><a href='AddEmployee' target='contentFrame'>Add New Employee</a></li>");
        out.println("<li><a href='ViewEmployee' target='contentFrame'>View All Employees</a></li>");
        out.println("<li><a href='UpdateEmployee' target='contentFrame'>Update Employee Details</a></li>");
        out.println("<li><a href='DeleteEmployee' target='contentFrame'>Delete Employee</a></li>");
        out.println("</ul>");
        out.println("</body></html>");
    }
}
