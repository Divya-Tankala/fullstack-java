import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UpdateEmployee extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<style>");
        out.println("body {");
        out.println("    font-family: Arial, sans-serif;");
        out.println("    background-color: #E8F0FE;");
        out.println("    margin: 0;");
        out.println("    padding: 0;");
        out.println("    display: flex;");
        out.println("    flex-direction: column;");
        out.println("    justify-content: center;");
        out.println("    align-items: center;");
        out.println("    height: 100vh;");
        out.println("    text-align: center;");
        out.println("}");
        out.println("h2 {");
        out.println("    color: #333;");
        out.println("    margin-bottom: 20px;");
        out.println("}");
        out.println("h4 {");
        out.println("    color: #555;");
        out.println("    margin-bottom: 20px;");
        out.println("}");
        out.println("form {");
        out.println("    background: #ffffff;");
        out.println("    border: 1px solid #dddddd;");
        out.println("    border-radius: 8px;");
        out.println("    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);");
        out.println("    padding: 20px;");
        out.println("    max-width: 400px;");
        out.println("    width: 100%;");
        out.println("}");
        out.println("form input[type='number'], form input[type='text'], form input[type='email'], form input[type='number'] {");
        out.println("    width: calc(100% - 20px);");
        out.println("    padding: 10px;");
        out.println("    margin: 10px 0;");
        out.println("    border: 1px solid #cccccc;");
        out.println("    border-radius: 4px;");
        out.println("    font-size: 14px;");
        out.println("    box-sizing: border-box;");
        out.println("}");
        out.println("form input[type='submit'] {");
        out.println("    width: 100%;");
        out.println("    background-color: #4A90E2;");
        out.println("    color: white;");
        out.println("    border: none;");
        out.println("    border-radius: 4px;");
        out.println("    padding: 10px;");
        out.println("    font-size: 16px;");
        out.println("    cursor: pointer;");
        out.println("}");
        out.println("form input[type='submit']:hover {");
        out.println("    background-color:#3B7BCA;");
        out.println("}");
        out.println(".message {");
        out.println("    background-color: #4CAF50;");
        out.println("    color: white;");
        out.println("    padding: 10px 20px;");
        out.println("    margin-top: 30px;");
        out.println("    margin-bottom: 20px;");
        out.println("    border-radius: 4px;");
        out.println("    font-size: 18px;");
        out.println("}");
        out.println(".view-link {");
        out.println("    background-color: #4A90E2;");
        out.println("    color: white;");
        out.println("    padding: 10px 20px;");
        out.println("    text-decoration: none;");
        out.println("    border-radius: 4px;");
        out.println("    font-size: 16px;");
        out.println("}");
        out.println(".view-link:hover {");
        out.println("    background-color: #3B7BCA;");
        out.println("}");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        
        out.println("<h2>Update Employee</h2>");
        out.println("<h4>Enter the Id of the Employee whose details need to be updated</h4>");
        out.println("<form>");
        out.println("ID: <input type='number' name='empId' required><br>");
        out.println("<input type='submit' value='Update Employee Details'>");
        out.println("</form>");
        
        String empIdParam = request.getParameter("empId");
        if (empIdParam != null && !empIdParam.isEmpty()) {
            int empId = Integer.parseInt(empIdParam);
            
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fsd", "root", "password");
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM emp WHERE Id = " + empId);
                
                if (rs.next()) {
                    String name = rs.getString("Name");
                    String email = rs.getString("Email");
                    String contact = rs.getString("Contact");
                    int salary = rs.getInt("Salary");
                    String department = rs.getString("Department");
                    out.println("<h2>Update Employee Details</h2>");
                    out.println("<form action='UpdateEmployee' method='post'>");
                    out.println("<input type='hidden' name='empId' value='" + empId + "'>");
                    out.println("Name: <input type='text' name='name' value='" + name + "' required><br>");
                    out.println("Email: <input type='email' name='email' value='" + email + "' required><br>");
                    out.println("Contact: <input type='text' name='contact' value='" + contact + "' required><br>");
                    out.println("Salary: <input type='number' name='salary' value='" + salary + "' required><br>");
                    out.println("Department: <input type='text' name='department' value='" + department + "' required><br>");
                    out.println("<input type='submit' value='Update Employee'>");
                    out.println("</form>");
                } else {
                    out.println("<div class='message'>Employee with ID " + empId + " not found.</div>");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                out.println("<div class='message'>SQL Error: " + e.getMessage() + "</div>");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(UpdateEmployee.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        out.println("</body>");
        out.println("</html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int empId = Integer.parseInt(request.getParameter("empId"));
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String contact = request.getParameter("contact");
        int salary = Integer.parseInt(request.getParameter("salary"));
        String department = request.getParameter("department");
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fsd", "root", "password");
            Statement stmt = con.createStatement();
            String query = String.format("UPDATE emp SET Name='%s',  Email='%s', Contact='%s', Salary=%d, Department='%s' WHERE Id=%d",
                    name,  email, contact, salary, department, empId);
            stmt.executeUpdate(query);
            response.sendRedirect("ViewEmployee"); // Redirect to view employees page
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateEmployee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
