
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AddEmployee extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Display the form to add an employee
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Add Employee</title>");
        //out.println("<link rel='stylesheet' type='text/css' href='Add.css'>"); // Link to CSS file
       ;
    out.println("<style>");
    out.println("body {");
    out.println("    font-family: Arial, sans-serif;");
    out.println("    background-color: #E8F0FE;");
    out.println("    align-items: center;");
    out.println("    margin: 0;");
    out.println("    padding: 0;");
    out.println("    display: flex;");
    out.println("    flex-direction: column;");
    out.println("    justify-content: center;");
    
    out.println("    height: 100vh;");
    out.println("    text-align: center;");
    out.println("}");
    out.println("h2 {");
    out.println("    color: #333;");
    out.println("    align-items: center;");
    out.println("    margin-bottom: 20px;");
    out.println("}");
    out.println("form {");
    out.println("    background: #ffffff;");
    out.println("    align-items: center;");
    out.println("    text-align: left;");
    out.println("    border: 1px solid #dddddd;");
    out.println("    border-radius: 8px;");
    out.println("    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);");
    out.println("    padding: 20px;");
    out.println("    max-width: 400px;");
    out.println("    width: 100%;");
    out.println("}");
    out.println("form input[type='text'],");
    out.println("form input[type='number'],");
    out.println("form input[type='email'] {");
    out.println("    width: calc(100% - 20px);");
    out.println("    padding: 10px;");
    out.println("    margin: 10px 0;");
    out.println("    border: 1px solid #cccccc;");
    out.println("    border-radius: 4px;");
    out.println("    font-size: 14px;");
    out.println("    box-sizing: border-box;");
    out.println("}");
    out.println("form input[type='submit'] {");
    out.println("    width: 100%;");
    out.println("    background-color: #4A90E2;");
    out.println("    color: white;");
    out.println("    border: none;");
    out.println("    border-radius: 4px;");
    out.println("    padding: 10px;");
    out.println("    font-size: 16px;");
    out.println("    cursor: pointer;");
    out.println("}");
    out.println("form input[type='submit']:hover {");
    out.println("    background-color: #3B7BCA;");
    out.println("}");
    out.println("</style>");
        out.println("</head>");
        out.println("<body>");        
        out.println("<h2>Add Employee</h2>");
        out.println("<form action='AddEmployee' method='post'>");
        out.println("ID: <input type='number' name='id' required><br>");
        out.println("Name: <input type='text' name='name' required><br>");
        out.println("Email: <input type='email' name='email' required><br>");
        out.println("Contact: <input type='text' name='contact' required><br>");
        out.println("Salary: <input type='number' name='salary' required><br>");
        out.println("Department: <input type='text' name='department' required><br>");
        out.println("<input type='submit' value='Add Employee'>");
        out.println("</form>");
        out.println("</body></html>");
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String contact = request.getParameter("contact");
        int salary = Integer.parseInt(request.getParameter("salary"));
        String department = request.getParameter("department");
                PrintWriter out = response.getWriter();


        try {
            Class.forName("com.mysql.jdbc.Driver");
           Connection con = DriverManager.getConnection ("jdbc:mysql://localhost:3306/fsd" ,"root", "password" );
            Statement stmt = con.createStatement();
            //String query = String.format("INSERT INTO emp (Name,Email, Contact, Salary, Department) VALUES ('%s', '%s', '%s', %d, '%s')",name, email, contact, salary, department);
            String query = String.format(
    "INSERT INTO `emp` (`Id`,`Name`, `Email`, `Contact`, `Salary`, `Department`) VALUES ('%d','%s', '%s', '%s', %d, '%s')",id,name, email, contact, salary, department);
            System.out.println("Executing Query: " + query);
            out.println("<html>");;
        out.println("<head>");
         out.println("<style>");
        out.println("body {");
        out.println("    font-family: Arial, sans-serif;");
        out.println("    background-color: #E8F0FE;");
        out.println("    margin: 0;");
        out.println("    padding: 0;");
        out.println("    display: flex;");
        out.println("    flex-direction: column;");
        out.println("    justify-content: center;");
        out.println("    align-items: center;");
        out.println("    height: 100vh;");
        out.println("    text-align: center;");
        out.println("}");
        out.println(".message {");
        out.println("    background-color: #4CAF50;");
        out.println("    color: white;");
        out.println("    padding: 10px 20px;");
        out.println("    margin: 20px 0;");
        out.println("    margin-top: 30px;");
        
        out.println("    border-radius: 4px;");
        out.println("    font-size: 18px;");
        out.println("}");
        out.println(".view-link {");
        out.println("    background-color: #4A90E2;");
        out.println("    color: white;");
        out.println("    padding: 10px 20px;");
        out.println("    text-decoration: none;");
        out.println("    border-radius: 4px;");
        out.println("    font-size: 16px;");
        out.println("}");
        out.println(".view-link:hover {");
        out.println("    background-color: #3B7BCA;");
        out.println("}");
        out.println("</style>");
        out.println("</head>");
        out.println("</body></html>");
            int rowsAffected = stmt.executeUpdate(query);
            if (rowsAffected > 0) {
                    out.println("<div class='message'>Employee with ID " + id + " has been added successfully.</div>");
                } 
                
                // Link to view the employees
                out.println("<a href='ViewEmployee' class='view-link'>View Employees</a>");
                //out.println("<a href='Main' class='view-link'>Main Menu</a>");
             
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("SQL Error: " + e.getMessage());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AddEmployee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
