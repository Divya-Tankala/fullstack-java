import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Header extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        // Create the Home Page with links and apply styling
        out.println("<html>");
        out.println("<head>");
        // Embedded CSS for styling
        out.println("<style>");
        out.println("body {");
        out.println("    font-family: Arial, sans-serif;");
        out.println("    background-color: #E8F0FE ;");
        out.println("    margin: 0;");
        out.println("    padding: 0;");
        out.println("    text-align: center;");
        out.println("    display: flex;");
        out.println("    justify-content: center;");
        out.println("    align-items: center;");
        out.println("    flex-direction: column;");
        out.println("    height: 100vh;");
        out.println("}");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        
        // Create menu links for navigation (side by side)
        out.println("<h2>Employee Management System</h2>");
        out.println("<h3>22251A05A2 - B.Joshitha</h3>");
        out.println("</body></html>");
    }
}
