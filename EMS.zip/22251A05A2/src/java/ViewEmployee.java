import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ViewEmployee extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fsd", "root", "password");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM emp");
            
            out.println("<html>");
            out.println("<head>");
            out.println("<style>");
            out.println("body {");
            out.println("    font-family: Arial, sans-serif;");
            out.println("    background-color: #E8F0FE;");
            out.println("    margin: 0;");
            out.println("    padding: 0;");
            out.println("    display: flex;");
            out.println("    flex-direction: column;");
            out.println("    align-items: center;");
            out.println("    justify-content: center;");
            out.println("    height: 100vh;");
            out.println("    text-align: center;");
            out.println("}");
            out.println("h2 {");
            out.println("    color: #333;");
            out.println("    margin-bottom: 20px;");
            out.println("}");
            out.println("table {");
            out.println("    width: 80%;");
            out.println("    border-collapse: collapse;");
            out.println("    margin: 20px 0;");
            out.println("}");
            out.println("table, th, td {");
            out.println("    border: 1px solid #ddd;");
            out.println("}");
            out.println("th, td {");
            out.println("    padding: 12px;");
            out.println("    text-align: center;");
            out.println("}");
            out.println("th {");
            out.println("    background-color: #3B7BCA;");
            out.println("    color: white;");
            out.println("}");
            out.println("tr:nth-child(even) {");
            out.println("    background-color: #f2f2f2;");
            out.println("}");
            out.println("a {");
            out.println("    background-color: #2196F3;");
            out.println("    color: white;");
            out.println("    padding: 10px 20px;");
            out.println("    text-decoration: none;");
            out.println("    border-radius: 4px;");
            out.println("    font-size: 16px;");
            out.println("    margin-top: 20px;");
            out.println("}");
            out.println("a:hover {");
            out.println("    background-color: #0b7dda;");
            out.println("}");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            
            out.println("<h2>Employee List</h2>");
            out.println("<table>");
            out.println("<tr><th>ID</th><th>Name</th><th>Email</th><th>Contact</th><th>Salary</th><th>Department</th></tr>");
            
            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + rs.getInt("Id") + "</td>");
                out.println("<td>" + rs.getString("Name") + "</td>");
                out.println("<td>" + rs.getString("Email") + "</td>");
                out.println("<td>" + rs.getString("Contact") + "</td>");
                out.println("<td>" + rs.getInt("Salary") + "</td>");
                out.println("<td>" + rs.getString("Department") + "</td>");
                out.println("</tr>");
            }
            out.println("</table>");
            //out.println("<a href='Main'>Main Menu</a>");
            
            out.println("</body>");
            out.println("</html>");
            
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ViewEmployee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
