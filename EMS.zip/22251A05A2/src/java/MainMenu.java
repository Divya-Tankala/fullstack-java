import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class MainMenu extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
         out.println("<html>");
        out.println("<head>");
        out.println("<style>");
        out.println("body {");
        out.println("    font-family: Arial, sans-serif;");
        out.println("    background-color: #E8F0FE ;");
        out.println("    margin: 0;");
        out.println("    padding: 0;");
        out.println("    text-align: center;");
        out.println("    display: flex;");
        out.println("    justify-content: center;");
        out.println("    align-items: center;");
        out.println("    flex-direction: column;");
        out.println("    height: 100vh;");
        out.println("}");
        out.println("h2 {");
        out.println("    color: #333;");
        out.println("    margin-top: 50px;");
        out.println("}");
        out.println("</style>");
        out.println("</head>");
        out.println("<h2>Welcome to Employee Management System</h2>");
        out.println("<p>Select an option from the menu to proceed.</p>");
        out.println("</body></html>");
    }
}
