import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Main extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Employee Management System</title>");
        out.println("<style>");
        out.println("body { margin: 0; padding: 0; font-family: Arial, sans-serif; }");
        out.println(".container { display: flex; flex-direction: column; height: 100vh; }");
        out.println(".header { flex: 0 1 80px; border-bottom: 2px solid #000; }");  
        out.println(".main-content { display: flex; flex: 1; border-top: 2px solid #000; }"); 
        out.println(".menu { flex: 0 1 250px; border-right: 2px solid #000; }");  
        out.println(".content { flex: 1; }");  
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");
        
        out.println("<iframe src='Header' name='headerFrame' class='header' height='100px' style='border-bottom:2px solid #000;'></iframe>");
        
        out.println("<div class='main-content'>");
        out.println("<iframe src='Menu' name='menuFrame' class='menu' style='border-right:2px solid #000;'></iframe>");
        
        out.println("<iframe src='MainMenu' name='contentFrame' class='content' style='border-left:2px solid #000;'></iframe>");
        
        out.println("</div>"); 
        
        out.println("</div>"); 
        
        out.println("</body>");
        out.println("</html>");
    }
}
